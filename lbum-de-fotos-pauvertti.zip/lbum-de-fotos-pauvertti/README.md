# Álbum de Fotos-PauVertti

A Pen created on CodePen.

Original URL: [https://codepen.io/PAULINA-ORTIZPEREZ-VERTTI/pen/PwPgvWp](https://codepen.io/PAULINA-ORTIZPEREZ-VERTTI/pen/PwPgvWp).

