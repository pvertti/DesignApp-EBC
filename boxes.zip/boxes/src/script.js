// Desafio de las CAJAS //

// Desafío 1: Cambiar el título .getElementById //

document.getElementById("btn-titulo").addEventListener("click",()=>
{
  const titulo=
        document.getElementById("titulo")
  titulo.textContent = "¡Bazinga!";
});

// Desafío 2: Cambiar el color de las cajas con .getElementsByClassName //

//Primero llamamos al botón, ya que el click la acción será sobre el botón //

document.getElementById("btn-cajas").addEventListener("click",()=>
{                                                   
 const cajas =                                          document.getElementsByClassName("caja")         
 
 //Ciclo FOR sirve para repetir una acción, siempre se inicia la variable en 0 //
 for (let i = 0; i < cajas.length; i++)
   {
     cajas[i].style.backgroundColor = "#FAC3CF"
   }
 });

// Desafio 3: Cambiar color de solo una caja con .querySelector //
document.getElementById("btn-primercaja").addEventListener("click",()=>
                                                     {                                                  const primeracaja =
   document.querySelector(".caja");
                                                      
primeracaja.style.backgroundColor = "#609150";
                                                      });

// Desafio 4: Cambiar color de los bordes con .query SelectorAll //

document.getElementById("btn-bordes").addEventListener("click",()=>
                                                     {
  const cajas =
        document.querySelectorAll(".caja");
  cajas.forEach(caja=>{
    caja.style.border = "5px solid #C81F51"
  });
});

