document.addEventListener('DOMContentLoaded', () => {

  document.getElementById('year').textContent = new Date().getFullYear();

  const API_POSTS = 'https://jsonplaceholder.typicode.com/posts?_limit=3'; 
  const API_USERS = 'https://randomuser.me/api/?results=4&nat=us,es,gb';

  function makeNewsItem(post) {
    const div = document.createElement('div');
    div.className = 'card news-item';

    const imgContainer = document.createElement('div');
    imgContainer.className = 'card-image';
    const img = document.createElement('img');
    img.src = `https://picsum.photos/seed/post${post.id}/200/140`;
    img.alt = 'foto noticia';
    imgContainer.appendChild(img);

    const body = document.createElement('div');
    body.className = 'card-content';
    const h4 = document.createElement('h4');
    h4.textContent = post.title;
    h4.style.margin = '0 0 6px';
    h4.style.fontFamily = 'Montserrat';
    const p = document.createElement('p');
    p.style.margin = 0;
    p.style.color = 'var(--muted)';
    p.textContent = post.body.slice(0, 140) + (post.body.length > 140 ? '…' : '');
    body.appendChild(h4);
    body.appendChild(p);

    div.appendChild(imgContainer);
    div.appendChild(body);
    return div;
  }

  function makeVolunteer(user) {
    const cont = document.createElement('div');
    cont.className = 'vol';
    const img = document.createElement('img');
    img.className = 'avatar';
    img.src = user.picture.medium;
    img.alt = user.name.first;
    const meta = document.createElement('div');
    const name = document.createElement('div');
    name.textContent = user.name.first + ' ' + user.name.last;
    name.style.fontWeight = '700';
    const role = document.createElement('div');
    role.textContent = user.location.city + ', ' + user.nat;
    role.style.color = 'var(--muted)';
    role.style.fontSize = '0.9rem';
    meta.appendChild(name);
    meta.appendChild(role);
    cont.appendChild(img);
    cont.appendChild(meta);
    return cont;
  }

  // Fetch posts (JSONPlaceholder)
  fetch(API_POSTS)
    .then(r => r.json())
    .then(posts => {
      const news = document.getElementById('news');
      if (news) {
        news.innerHTML = ''; // Esto limpia el contenido estático
        posts.forEach(p => news.appendChild(makeNewsItem(p)));
      }
    })
    .catch(err => {
      console.error('Error cargando posts', err);
      const news = document.getElementById('news');
      if (news) {
        news.innerHTML = '<div class="card">No se pudieron cargar las noticias.</div>';
      }
    });

  // Fetch volunteers (RandomUser)
  fetch(API_USERS)
    .then(r => r.json())
    .then(resp => {
      const users = resp.results || [];
      const vols = document.getElementById('vols');
      if (vols) {
        vols.innerHTML = '';
        users.forEach(u => vols.appendChild(makeVolunteer(u)));
      }
    })
    .catch(err => {
      console.error('Error cargando usuarios', err);
      const vols = document.getElementById('vols');
      if (vols) {
        vols.innerHTML = '<div class="card">No se pudieron cargar los perfiles.</div>';
      }
    });

  const contactForm = document.getElementById('contact-form');
  if (contactForm) {
    contactForm.addEventListener('submit', e => {
      e.preventDefault();
      alert('Gracias — tu mensaje se ha registrado (demo).');
      e.target.reset();
    });
  }

});